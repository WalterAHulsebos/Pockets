// UltEvents // Copyright 2018 Kybernetik //

#if UNITY_EDITOR

using System;
using UnityEditor;
using UnityEngine;

namespace UltEvents
{
    internal static class SerializedPropertyContextMenu
    {
        /************************************************************************************************************************/

        [InitializeOnLoadMethod]
        private static void OnPropertyContextMenu()
        {
            EditorApplication.contextualPropertyMenu += (menu, property) =>
            {
                if (property.propertyType != SerializedPropertyType.Generic)
                    return;

                var accessor = SerializedPropertyAccessor.GetAccessor(property);
                if (accessor == null)
                    return;

                if (typeof(UltEventBase).IsAssignableFrom(accessor.FieldType))
                {
                    AddEventFunctions(menu, property, accessor);
                }
                else if (accessor.FieldType == typeof(PersistentCall))
                {
                    AddCallClipboardItems(menu, property, accessor);
                }
            };
        }

        /************************************************************************************************************************/

        public static void AddEventFunctions(GenericMenu menu, SerializedProperty property, SerializedPropertyAccessor accessor)
        {
            property = property.Copy();

            if (accessor.FieldType == typeof(UltEvent))
            {
                menu.AddItem(new GUIContent("Invoke Event"), false, () =>
                {
                    var events = SerializedPropertyAccessor.GetValues<UltEvent>(property);
                    for (int i = 0; i < events.Length; i++)
                        (events[i] as UltEvent)?.Invoke();
                    SerializedPropertyAccessor.OnPropertyChanged(property);
                });
            }

            AddEventClipboardItems(menu, property, accessor);

            menu.AddItem(new GUIContent("Clear Event"), false, () =>
            {
                SerializedPropertyAccessor.ModifyValues<UltEventBase>(property, (e) =>
                {
                    e?.Clear();
                }, "Clear Event");
            });

            menu.AddItem(new GUIContent("Log Description"), false, () =>
            {
                var targets = property.serializedObject.targetObjects;
                var events = SerializedPropertyAccessor.GetValues<UltEventBase>(property);

                for (int i = 0; i < events.Length; i++)
                    Debug.Log(events[i], targets[i]);
            });
        }

        /************************************************************************************************************************/

        private static UltEventBase _EventClipboard;

        private static void AddEventClipboardItems(GenericMenu menu, SerializedProperty property, SerializedPropertyAccessor accessor)
        {
            // Copy Event.
            menu.AddItem(new GUIContent("Copy Event"), false, () =>
            {
                var e = (UltEventBase)accessor.GetValue(property.serializedObject.targetObject);
                var eventType = e.GetType();

                if (_EventClipboard == null || _EventClipboard.GetType() != eventType)
                    _EventClipboard = (UltEventBase)Activator.CreateInstance(eventType);

                _EventClipboard.CopyFrom(e);
            });

            // Paste Event.
            if (_EventClipboard != null)
            {
                menu.AddItem(new GUIContent("Paste Event"), false, () =>
                {
                    SerializedPropertyAccessor.ModifyValues<UltEventBase>(property, (e) =>
                    {
                        e.CopyFrom(_EventClipboard);
                    }, "Paste Event");
                });
            }
            else
            {
                menu.AddDisabledItem(new GUIContent("Paste Event"));
            }

            // Paste Call.
            if (_CallClipboard != null)
            {
                menu.AddItem(new GUIContent("Paste Call"), false, () =>
                {
                    SerializedPropertyAccessor.ModifyValues<UltEventBase>(property, (e) =>
                    {
                        var call = new PersistentCall();
                        call.CopyFrom(_CallClipboard);

                        if (e._PersistentCalls == null)
                            e._PersistentCalls = new System.Collections.Generic.List<PersistentCall>();
                        e._PersistentCalls.Add(call);

                    }, "Paste PersistentCall");
                });
            }
            else
            {
                menu.AddDisabledItem(new GUIContent("Paste Call"));
            }
        }

        /************************************************************************************************************************/

        private static PersistentCall _CallClipboard;

        private static void AddCallClipboardItems(GenericMenu menu, SerializedProperty property, SerializedPropertyAccessor accessor)
        {
            menu.AddItem(new GUIContent("Copy Call"), false, () =>
            {
                if (_CallClipboard == null)
                    _CallClipboard = new PersistentCall();

                var call = (PersistentCall)accessor.GetValue(property.serializedObject.targetObject);
                _CallClipboard.CopyFrom(call);
            });

            if (_CallClipboard != null)
            {
                menu.AddItem(new GUIContent("Paste Call"), false, () =>
                {
                    SerializedPropertyAccessor.ModifyValues<PersistentCall>(property, (call) =>
                    {
                        call.CopyFrom(_CallClipboard);
                    }, "Paste PersistentCall");
                });
            }
            else
            {
                menu.AddDisabledItem(new GUIContent("Paste Call"));
            }
        }

        /************************************************************************************************************************/

        public static void AddPropertyModifierFunction(GenericMenu menu, SerializedProperty property, string label, Action function)
        {
            menu.AddItem(new GUIContent(label), false, () =>
            {
                function();
                property.serializedObject.ApplyModifiedProperties();
            });
        }

        public static void AddPropertyModifierFunction(GenericMenu menu, SerializedProperty property, string label, Action<SerializedProperty> function)
        {
            menu.AddItem(new GUIContent(label), false, () =>
            {
                ForEachTarget(property, function);
            });
        }

        /************************************************************************************************************************/

        private static void ForEachTarget(SerializedProperty property, Action<SerializedProperty> function)
        {
            var targets = property.serializedObject.targetObjects;

            if (targets.Length == 1)
            {
                function(property);
                property.serializedObject.ApplyModifiedProperties();
            }
            else
            {
                var path = property.propertyPath;
                for (int i = 0; i < targets.Length; i++)
                {
                    using (var serializedObject = new SerializedObject(targets[i]))
                    {
                        property = serializedObject.FindProperty(path);
                        function(property);
                        property.serializedObject.ApplyModifiedProperties();
                    }
                }
            }
        }

        /************************************************************************************************************************/
    }
}

#endif