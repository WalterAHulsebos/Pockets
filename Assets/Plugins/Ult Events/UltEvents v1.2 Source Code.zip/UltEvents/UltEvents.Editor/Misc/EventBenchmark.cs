﻿// UltEvents // Copyright 2018 Kybernetik //

//#define BENCHMARKS
#if BENCHMARKS && UNITY_EDITOR

#pragma warning disable CS1591 // Missing XML comment for publicly visible type or member

using System;
using UnityEditor;
using UnityEngine;
using UnityEngine.Events;

namespace UltEvents
{
    public abstract class EventBenchmark : MonoBehaviour
    {
        /************************************************************************************************************************/

        public void Awake()
        {
            double start = EditorApplication.timeSinceStartup;
            Invoke();
            Debug.Log(EditorApplication.timeSinceStartup - start);
        }

        protected abstract void Invoke();

        /************************************************************************************************************************/
    }

    public sealed class UnityEventBenchmark : EventBenchmark
    {
        /************************************************************************************************************************/

        public UnityEvent e;

        protected override void Invoke()
        {
            e.Invoke();
        }

        /************************************************************************************************************************/
    }

    public sealed class UltEventBenchmark : EventBenchmark
    {
        /************************************************************************************************************************/

        public UltEvent e;

        protected override void Invoke()
        {
            e.Invoke();
        }

        /************************************************************************************************************************/
    }

    public sealed class EventPrefabBenchmark : MonoBehaviour
    {
        /************************************************************************************************************************/

        public string prefabPath;

        public void Update()
        {
            if (Time.timeSinceLevelLoad < 1)
                return;

            System.Threading.Thread.Sleep(100);
            double start = EditorApplication.timeSinceStartup;
            Instantiate(Resources.Load<GameObject>(prefabPath));
            Debug.Log(EditorApplication.timeSinceStartup - start);
            enabled = false;
        }

        /************************************************************************************************************************/
    }
}

#endif