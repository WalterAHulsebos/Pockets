﻿// UltEvents // Copyright 2018 Kybernetik //

using UnityEngine;

namespace UltEvents
{
    /// <summary>
    /// A component which encapsulates a single <see cref="UltEvent"/>.
    /// </summary>
    [AddComponentMenu("Ult Events/Ult Event Holder")]
    public class UltEventHolder : MonoBehaviour
    {
        /************************************************************************************************************************/

        [SerializeField]
        private UltEvent _Event;

        /// <summary>The encapsulated event.</summary>
        public UltEvent Event
        {
            get
            {
                if (_Event == null)
                    _Event = new UltEvent();
                return _Event;
            }
            set { _Event = value; }
        }

        /************************************************************************************************************************/

        /// <summary>Calls Event.Invoke().</summary>
        public virtual void Invoke()
        {
            if (_Event != null)
                _Event.Invoke();
        }

        /************************************************************************************************************************/
    }
}