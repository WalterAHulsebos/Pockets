﻿// UltEvents // Copyright 2018 Kybernetik //

using UnityEngine;

namespace UltEvents
{
    /// <summary>
    /// Holds <see cref="UltEvent"/>s which are called by various <see cref="MonoBehaviour"/> update events:
    /// Update, LateUpdate, and FixedUpdate.
    /// </summary>
    [AddComponentMenu("Ult Events/Update Events")]
    [DisallowMultipleComponent]
    public class UpdateEvents : MonoBehaviour
    {
        /************************************************************************************************************************/

        [SerializeField]
        private UltEvent _UpdateEvent;

        /// <summary>This event is invoked by <see cref="Update"/>.</summary>
        public UltEvent UpdateEvent
        {
            get
            {
                if (_UpdateEvent == null)
                    _UpdateEvent = new UltEvent();
                return _UpdateEvent;
            }
            set { _UpdateEvent = value; }
        }

        /// <summary>Invokes <see cref="UpdateEvent"/>.</summary>
        public virtual void Update()
        {
            if (_UpdateEvent != null)
                _UpdateEvent.Invoke();
        }

        /************************************************************************************************************************/

        [SerializeField]
        private UltEvent _LateUpdateEvent;

        /// <summary>This event is invoked by <see cref="LateUpdate"/>.</summary>
        public UltEvent LateUpdateEvent
        {
            get
            {
                if (_LateUpdateEvent == null)
                    _LateUpdateEvent = new UltEvent();
                return _LateUpdateEvent;
            }
            set { _LateUpdateEvent = value; }
        }

        /// <summary>Invokes <see cref="LateUpdateEvent"/>.</summary>
        public virtual void LateUpdate()
        {
            if (_LateUpdateEvent != null)
                _LateUpdateEvent.Invoke();
        }

        /************************************************************************************************************************/

        [SerializeField]
        private UltEvent _FixedUpdateEvent;

        /// <summary>This event is invoked by <see cref="FixedUpdate"/>.</summary>
        public UltEvent FixedUpdateEvent
        {
            get
            {
                if (_FixedUpdateEvent == null)
                    _FixedUpdateEvent = new UltEvent();
                return _FixedUpdateEvent;
            }
            set { _FixedUpdateEvent = value; }
        }

        /// <summary>Invokes <see cref="FixedUpdateEvent"/>.</summary>
        public virtual void FixedUpdate()
        {
            if (_FixedUpdateEvent != null)
                _FixedUpdateEvent.Invoke();
        }

        /************************************************************************************************************************/
    }
}