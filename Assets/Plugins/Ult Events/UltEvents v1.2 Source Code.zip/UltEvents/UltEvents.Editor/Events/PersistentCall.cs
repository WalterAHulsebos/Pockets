﻿// UltEvents // Copyright 2018 Kybernetik //

using System;
using System.Reflection;
using System.Reflection.Emit;
using System.Text;
using UnityEngine;

namespace UltEvents
{
    /// <summary>
    /// Encapsulates a delegate so it can be serialized for <see cref="UltEventBase"/>.
    /// </summary>
    [Serializable]
    public sealed class PersistentCall
#if UNITY_EDITOR
        : ISerializationCallbackReceiver
#endif
    {
        /************************************************************************************************************************/
        #region Fields and Properties
        /************************************************************************************************************************/

        [SerializeField]
        internal UnityEngine.Object _Target;

        /// <summary>The object on which the persistent method is called.</summary>
        public UnityEngine.Object Target
        {
            get { return _Target; }
        }

        /************************************************************************************************************************/

        [SerializeField]
        internal string _MethodName;

        /// <summary>The name of the persistent method.</summary>
        public string MethodName
        {
            get { return _MethodName; }
        }

        /************************************************************************************************************************/

        [SerializeField]
        internal PersistentArgument[] _PersistentArguments = NoArguments;

        /// <summary>The arguments which are passed to the method when it is invoked.</summary>
        public PersistentArgument[] PersistentArguments
        {
            get { return _PersistentArguments; }
        }

        /************************************************************************************************************************/

        [NonSerialized]
        internal MethodInfo _Method;

        /// <summary>The method which this call encapsulates.</summary>
        public MethodInfo Method
        {
            get
            {
                if (_Method == null)
                {
                    GetMethodDetails(out Type declaringType, out string methodName);
                    if (declaringType == null || string.IsNullOrEmpty(methodName))
                        return null;

                    var argumentCount = _PersistentArguments.Length;
                    var parameters = ArrayCache<Type>.GetTempArray(argumentCount);
                    for (int i = 0; i < argumentCount; i++)
                    {
                        parameters[i] = _PersistentArguments[i].SystemType;
                    }

                    const BindingFlags Flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
                    _Method = declaringType.GetMethod(methodName, Flags, null, parameters, null);
                }

                return _Method;
            }
        }

        internal MethodInfo GetMethodSafe()
        {
            try { return Method; }
            catch { return null; }
        }

        /************************************************************************************************************************/
#if UNITY_EDITOR
        /************************************************************************************************************************/

        void ISerializationCallbackReceiver.OnBeforeSerialize()
        {
            // Always clear the cached method in the editor in case the fields have been directly modified by Inspector or Undo operations.
            _Method = null;
        }

        void ISerializationCallbackReceiver.OnAfterDeserialize()
        {
            _Method = null;
        }

        /************************************************************************************************************************/
#endif
        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/

        /// <summary>Constructs a new <see cref="PersistentCall"/> with default values.</summary>
        public PersistentCall() { }

        /// <summary>Constructs a new <see cref="PersistentCall"/> to serialize the specified 'method'.</summary>
        public PersistentCall(MethodInfo method, UnityEngine.Object target)
        {
            SetMethod(method, target);
        }

        /// <summary>Constructs a new <see cref="PersistentCall"/> to serialize the specified 'method'.</summary>
        public PersistentCall(Delegate method)
        {
            SetMethod(method);
        }

        /// <summary>Constructs a new <see cref="PersistentCall"/> to serialize the specified 'method'.</summary>
        public PersistentCall(Action method)
        {
            SetMethod(method);
        }

        /************************************************************************************************************************/

        /// <summary>Sets the method which this call encapsulates.</summary>
        public void SetMethod(MethodInfo method, UnityEngine.Object target)
        {
            _Method = method;
            _Target = target;

            if (method != null)
            {
                if (method.IsStatic)
                {
                    _MethodName = method.DeclaringType.AssemblyQualifiedName + "." + method.Name;
                    _Target = null;
                }
                else _MethodName = method.Name;

                var parameters = method.GetParameters();

                if (_PersistentArguments == null || _PersistentArguments.Length != parameters.Length)
                {
                    _PersistentArguments = NewArgumentArray(parameters.Length);
                }

                for (int i = 0; i < _PersistentArguments.Length; i++)
                {
                    var parameter = parameters[i];
                    var persistentArgument = _PersistentArguments[i];

                    persistentArgument.SystemType = parameter.ParameterType;

                    switch (persistentArgument.Type)
                    {
                        case PersistentArgumentType.Parameter:
                        case PersistentArgumentType.ReturnValue:
                            break;
                        default:
                            if ((parameter.Attributes & ParameterAttributes.HasDefault) == ParameterAttributes.HasDefault)
                            {
                                persistentArgument.Value = parameter.DefaultValue;
                            }
                            break;
                    }
                }

            }
            else
            {
                _MethodName = null;
                _PersistentArguments = NoArguments;
            }
        }

        /// <summary>Sets the delegate which this call encapsulates.</summary>
        public void SetMethod(Delegate method)
        {
            if (method.Target == null)
                SetMethod(method.Method, null);
            else if (method.Target is UnityEngine.Object target)
                SetMethod(method.Method, target);
            else
                throw new InvalidOperationException("SetMethod failed because action.Target is not a UnityEngine.Object.");
        }

        /// <summary>Sets the delegate which this call encapsulates.</summary>
        public void SetMethod(Action method)
        {
            SetMethod((Delegate)method);
        }

        /************************************************************************************************************************/

        private static readonly PersistentArgument[] NoArguments = new PersistentArgument[0];

        private static PersistentArgument[] NewArgumentArray(int length)
        {
            if (length == 0)
            {
                return NoArguments;
            }
            else
            {
                var array = new PersistentArgument[length];

                for (int i = 0; i < length; i++)
                    array[i] = new PersistentArgument();

                return array;
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Acquire a delegate based on the <see cref="Target"/> and <see cref="MethodName"/> and invoke it.
        /// </summary>
        public object Invoke()
        {
            if (Method == null)
            {
                Debug.LogWarning("Attempted to Invoke an UltEvent.PersistentCall which couldn't find it's method: " + MethodName);
                return null;
            }

            object[] parameters;
            if (_PersistentArguments != null && _PersistentArguments.Length > 0)
            {
                parameters = ArrayCache<object>.GetTempArray(_PersistentArguments.Length);
                for (int i = 0; i < parameters.Length; i++)
                {
                    parameters[i] = _PersistentArguments[i].Value;
                }
            }
            else parameters = null;

            UltEventBase.UpdateLinkedValueOffsets();
            return _Method.Invoke(_Target, parameters);
        }

        /************************************************************************************************************************/

        /// <summary>Sets the value of the first persistent argument.</summary>
        public void SetArguments(object argument0)
        {
            PersistentArguments[0].Value = argument0;
        }

        /// <summary>Sets the value of the first and second persistent arguments.</summary>
        public void SetArguments(object argument0, object argument1)
        {
            PersistentArguments[0].Value = argument0;
            PersistentArguments[1].Value = argument1;
        }

        /// <summary>Sets the value of the first, second, and third persistent arguments.</summary>
        public void SetArguments(object argument0, object argument1, object argument2)
        {
            PersistentArguments[0].Value = argument0;
            PersistentArguments[1].Value = argument1;
            PersistentArguments[2].Value = argument2;
        }

        /// <summary>Sets the value of the first, second, third, and fourth persistent arguments.</summary>
        public void SetArguments(object argument0, object argument1, object argument2, object argument3)
        {
            PersistentArguments[0].Value = argument0;
            PersistentArguments[1].Value = argument1;
            PersistentArguments[2].Value = argument2;
            PersistentArguments[3].Value = argument3;
        }

        /************************************************************************************************************************/

        internal void GetMethodDetails(out Type declaringType, out string methodName)
        {
            GetMethodDetails(_MethodName, _Target, out declaringType, out methodName);
        }

        internal static void GetMethodDetails(string serializedMethodName, UnityEngine.Object target, out Type declaringType, out string methodName)
        {
            if (string.IsNullOrEmpty(serializedMethodName))
            {
                declaringType = null;
                methodName = null;
                return;
            }

            if (target == null)
            {
                var lastDot = serializedMethodName.LastIndexOf('.');
                if (lastDot < 0)
                {
                    declaringType = null;
                    methodName = serializedMethodName;
                }
                else
                {
                    declaringType = Type.GetType(serializedMethodName.Substring(0, lastDot));
                    lastDot++;
                    methodName = serializedMethodName.Substring(lastDot, serializedMethodName.Length - lastDot);
                }
            }
            else
            {
                declaringType = target.GetType();
                methodName = serializedMethodName;
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Returns true if the specified 'type' can be represented by a non-linked <see cref="PersistentArgument"/>.
        /// </summary>
        public static bool IsSupportedNative(Type type)
        {
            return
                type == typeof(bool) ||
                type == typeof(string) ||
                type == typeof(int) ||
                (type.IsEnum && Enum.GetUnderlyingType(type) == typeof(int)) ||
                type == typeof(float) ||
                type == typeof(Vector2) ||
                type == typeof(Vector3) ||
                type == typeof(Vector4) ||
                type == typeof(Quaternion) ||
                type == typeof(Color) ||
                type == typeof(Color32) ||
                type == typeof(Rect) ||
                type == typeof(UnityEngine.Object) || type.IsSubclassOf(typeof(UnityEngine.Object));
        }

        /// <summary>
        /// Returns true if the type of each of the 'parameters' can be represented by a non-linked <see cref="PersistentArgument"/>.
        /// </summary>
        public static bool IsSupportedNative(ParameterInfo[] parameters)
        {
            for (int i = 0; i < parameters.Length; i++)
            {
                if (!IsSupportedNative(parameters[i].ParameterType))
                    return false;
            }

            return true;
        }

        /************************************************************************************************************************/

        /// <summary>Copies the contents of the 'target' call to this call.</summary>
        public void CopyFrom(PersistentCall target)
        {
            _Target = target._Target;
            _MethodName = target._MethodName;
            _Method = target._Method;

            _PersistentArguments = new PersistentArgument[target._PersistentArguments.Length];
            for (int i = 0; i < _PersistentArguments.Length; i++)
            {
                _PersistentArguments[i] = target._PersistentArguments[i].Clone();
            }
        }

        /************************************************************************************************************************/

        /// <summary>Returns a description of this call.</summary>
        public override string ToString()
        {
            var text = new StringBuilder();
            ToString(text);
            return text.ToString();
        }

        /// <summary>Appends a description of this call.</summary>
        public void ToString(StringBuilder text)
        {
            text.Append(nameof(PersistentCall) + ": MethodName=");
            text.Append(_MethodName);
            text.Append(", Target=");
            text.Append(_Target != null ? _Target.ToString() : "null");
            text.Append(", PersistentArguments=");
            UltEventUtils.AppendDeepToString(text, _PersistentArguments.GetEnumerator(), "\n        ");
        }

        /************************************************************************************************************************/
    }
}