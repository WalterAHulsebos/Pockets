﻿// UltEvents // Copyright 2018 Kybernetik //

using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Events;

namespace UltEvents
{
    /// <summary>
    /// A serializable event with no parameters which can be viewed and configured in the inspector.
    /// <para></para>
    /// This is a more versatile and user friendly implementation than <see cref="UnityEvent"/>.
    /// </summary>
    [Serializable]
    public sealed class UltEvent : UltEventBase
    {
        /************************************************************************************************************************/
        #region Fields and Properties
        /************************************************************************************************************************/

        /// <summary>
        /// Delegates registered to this event are serialized as <see cref="PersistentCall"/>s and are invoked by
        /// <see cref="Invoke"/> before all <see cref="dynamicCalls"/>.
        /// </summary>
        public event Action persistentCalls
        {
            add
            {
                AddPersistentCall(value);
            }
            remove
            {
                RemovePersistentCall(value);
            }
        }

        /************************************************************************************************************************/

        private Action _DynamicCalls;

        /// <summary>
        /// Delegates registered here are invoked by <see cref="Invoke"/> after all <see cref="persistentCalls"/>.
        /// </summary>
        public event Action dynamicCalls
        {
            add
            {
                _DynamicCalls += value;
                OnDynamicCallsChanged();
            }
            remove
            {
                _DynamicCalls -= value;
                OnDynamicCallsChanged();
            }
        }

        /// <summary>
        /// The non-serialized method and parameter details of this event.
        /// Delegates registered here are called by <see cref="Invoke"/> after all <see cref="persistentCalls"/>.
        /// </summary>
        protected override Delegate DynamicCalls { get => _DynamicCalls; set => _DynamicCalls = value as Action; }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Operators and Call Registration
        /************************************************************************************************************************/

        /// <summary>
        /// Ensures that 'e' isn't null and adds 'method' to its <see cref="persistentCalls"/> (if in edit mode) or
        /// <see cref="dynamicCalls"/> (in play mode and at runtime).
        /// </summary>
        public static UltEvent operator +(UltEvent e, Action method)
        {
            if (e == null)
                e = new UltEvent();

#if UNITY_EDITOR
            if (!UnityEditor.EditorApplication.isPlaying && method.Target is UnityEngine.Object)
            {
                e.persistentCalls += method;
                return e;
            }
#endif

            e.dynamicCalls += method;
            return e;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// If 'e' isn't null, this method removes 'method' from its <see cref="persistentCalls"/> (if in edit mode) or
        /// <see cref="dynamicCalls"/> (in play mode and at runtime).
        /// </summary>
        public static UltEvent operator -(UltEvent e, Action method)
        {
            if (e == null)
                return null;

#if UNITY_EDITOR
            if (!UnityEditor.EditorApplication.isPlaying && method.Target is UnityEngine.Object)
            {
                e.persistentCalls -= method;
                return e;
            }
#endif

            e.dynamicCalls -= method;
            return e;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Creates a new <see cref="UltEventBase"/> and adds 'method' to its <see cref="persistentCalls"/> (if in edit
        /// mode), or <see cref="dynamicCalls"/> (in play mode and at runtime).
        /// </summary>
        public static implicit operator UltEvent(Action method)
        {
            if (method != null)
            {
                var e = new UltEvent();
                e += method;
                return e;
            }
            else return null;
        }

        /************************************************************************************************************************/

        /// <summary>Ensures that 'e' isn't null and adds 'method' to its <see cref="dynamicCalls"/>.</summary>
        public static void AddDynamicCall(ref UltEvent e, Action method)
        {
            if (e == null)
                e = new UltEvent();

            e.dynamicCalls += method;
        }

        /// <summary>If 'e' isn't null, this method removes 'method' from its <see cref="dynamicCalls"/>.</summary>
        public static void RemoveDynamicCall(ref UltEvent e, Action method)
        {
            if (e != null)
                e.dynamicCalls -= method;
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
#if UNITY_EDITOR

        /// <summary>The types of each of this event's parameters.</summary>
        public override Type[] ParameterTypes => Type.EmptyTypes;

#endif
        /************************************************************************************************************************/

        /// <summary>
        /// Invokes all <see cref="persistentCalls"/> then all <see cref="dynamicCalls"/>.
        /// <para></para>
        /// See also: <seealso cref="InvokeSafe"/> and <seealso cref="UltEventUtils.InvokeX(UltEvent)"/>.
        /// </summary>
        public void Invoke()
        {
            InvokePersistentCalls();
            _DynamicCalls?.Invoke();
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Invokes all <see cref="persistentCalls"/> then all <see cref="dynamicCalls"/> inside a try/catch block
        /// which logs any exceptions that are thrown.
        /// <para></para>
        /// See also: <seealso cref="Invoke"/> and <seealso cref="UltEventUtils.InvokeX(UltEvent)"/>.
        /// </summary>
        public void InvokeSafe()
        {
            try
            {
                Invoke();
            }
            catch (Exception ex)
            {
                Debug.LogException(ex);
            }
        }

        /************************************************************************************************************************/
    }
}