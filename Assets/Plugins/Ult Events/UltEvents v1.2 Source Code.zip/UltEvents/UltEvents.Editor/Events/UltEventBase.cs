﻿// UltEvents // Copyright 2018 Kybernetik //

using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using UnityEngine;
using UnityEngine.Events;

namespace UltEvents
{
    /// <summary>
    /// A serializable event which can be viewed and configured in the inspector.
    /// <para></para>
    /// This is a more versatile and user friendly implementation than <see cref="UnityEvent"/>.
    /// </summary>
    [Serializable]
    public abstract class UltEventBase
    {
        /************************************************************************************************************************/
        #region Fields and Properties
        /************************************************************************************************************************/

        [SerializeField]
        internal List<PersistentCall> _PersistentCalls;

        /// <summary>
        /// The serialized method and parameter details of this event.
        /// </summary>
        public List<PersistentCall> PersistentCalls
        {
            get { return _PersistentCalls; }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// The non-serialized method and parameter details of this event.
        /// </summary>
        protected abstract Delegate DynamicCalls { get; set; }

        /// <summary>
        /// Clears the cached invocation list of <see cref="DynamicCalls"/>.
        /// </summary>
        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        protected void OnDynamicCallsChanged()
        {
#if UNITY_EDITOR
            _DynamicCallInvocationList = null;
#endif
        }

        /************************************************************************************************************************/
#if UNITY_EDITOR
        /************************************************************************************************************************/

        internal bool HasAnyDynamicCalls()
        {
            return DynamicCalls != null;
        }

        /************************************************************************************************************************/

        private Delegate[] _DynamicCallInvocationList;

        internal Delegate[] GetDynamicCallInvocationList()
        {
            if (_DynamicCallInvocationList == null && DynamicCalls != null)
                _DynamicCallInvocationList = DynamicCalls.GetInvocationList();

            return _DynamicCallInvocationList;
        }

        internal int GetDynamicCallInvocationListCount()
        {
            if (DynamicCalls == null)
                return 0;
            else
                return GetDynamicCallInvocationList().Length;
        }

        /************************************************************************************************************************/
#endif
        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Operators and Call Registration
        /************************************************************************************************************************/

        /// <summary>Ensures that 'e' isn't null and adds 'method' to its <see cref="PersistentCalls"/>.</summary>
        public static PersistentCall AddPersistentCall<T>(ref T e, Delegate method) where T : UltEventBase, new()
        {
            if (e == null)
                e = new T();

            return e.AddPersistentCall(method);
        }

        /// <summary>Ensures that 'e' isn't null and adds 'method' to its <see cref="PersistentCalls"/>.</summary>
        public static PersistentCall AddPersistentCall<T>(ref T e, Action method) where T : UltEventBase, new()
        {
            if (e == null)
                e = new T();

            return e.AddPersistentCall(method);
        }

        /************************************************************************************************************************/

        /// <summary>If 'e' isn't null, this method removes 'method' from its <see cref="PersistentCalls"/>.</summary>
        public static void RemovePersistentCall(ref UltEventBase e, Delegate method)
        {
            if (e != null)
                e.RemovePersistentCall(method);
        }

        /// <summary>If 'e' isn't null, this method removes 'method' from its <see cref="PersistentCalls"/>.</summary>
        public static void RemovePersistentCall(ref UltEventBase e, Action method)
        {
            if (e != null)
                e.RemovePersistentCall(method);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Add the specified 'method to the persistent call list.
        /// </summary>
        public PersistentCall AddPersistentCall(Delegate method)
        {
            if (_PersistentCalls == null)
                _PersistentCalls = new List<PersistentCall>(4);

            var call = new PersistentCall(method);
            _PersistentCalls.Add(call);
            return call;
        }

        /// <summary>
        /// Remove the specified 'method from the persistent call list.
        /// </summary>
        public void RemovePersistentCall(Delegate method)
        {
            if (_PersistentCalls == null)
                return;

            for (int i = 0; i < _PersistentCalls.Count; i++)
            {
                var call = _PersistentCalls[i];
                if (call.GetMethodSafe() == method.Method && ReferenceEquals(call.Target, method.Target))
                {
                    _PersistentCalls.RemoveAt(i);
                    return;
                }
            }
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/

        /// <summary>Invokes all <see cref="PersistentCalls"/> registered to this event.</summary>
        protected void InvokePersistentCalls()
        {
            var originalParameterOffset = _ParameterOffset;
            var originalReturnValueOffset = _ReturnValueOffset;

            try
            {
                if (_PersistentCalls != null)
                {
                    for (int i = 0; i < _PersistentCalls.Count; i++)
                    {
                        var result = _PersistentCalls[i].Invoke();
                        LinkedValueCache.Add(result);
                        _ParameterOffset = originalParameterOffset;
                        _ReturnValueOffset = originalReturnValueOffset;
                    }
                }
            }
            finally
            {
                LinkedValueCache.RemoveRange(originalParameterOffset, LinkedValueCache.Count - originalParameterOffset);
                _ParameterOffset = _ReturnValueOffset = originalParameterOffset;
            }
        }

        /************************************************************************************************************************/
        #region Linked Value Cache (Parameters and Returned Values)
        /************************************************************************************************************************/

        private static readonly List<object> LinkedValueCache = new List<object>();
        private static int _ParameterOffset, _ReturnValueOffset;

        /************************************************************************************************************************/

        internal static void UpdateLinkedValueOffsets()
        {
            _ParameterOffset = _ReturnValueOffset = LinkedValueCache.Count;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Sets the number of parameters passed to this event.
        /// </summary>
        protected static void CacheParameter(object value)
        {
            LinkedValueCache.Add(value);
            _ReturnValueOffset = LinkedValueCache.Count;
        }

        /************************************************************************************************************************/

        internal static int ReturnedValueCount
        {
            get { return LinkedValueCache.Count - _ReturnValueOffset; }
        }

        /************************************************************************************************************************/

        internal static object GetParameterValue(int index)
        {
            return LinkedValueCache[_ParameterOffset + index];
        }

        internal static object GetReturnedValue(int index)
        {
            return LinkedValueCache[_ReturnValueOffset + index];
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Parameter Display
#if UNITY_EDITOR
        /************************************************************************************************************************/

        /// <summary>The type of each of this event's parameters.</summary>
        public abstract Type[] ParameterTypes { get; }

        /************************************************************************************************************************/

        private static readonly Dictionary<Type, ParameterInfo[]>
            EventTypeToParameters = new Dictionary<Type, ParameterInfo[]>();

        internal ParameterInfo[] Parameters
        {
            get
            {
                var type = GetType();

                if (!EventTypeToParameters.TryGetValue(type, out var parameters))
                {
                    var invokeMethod = type.GetMethod("Invoke", ParameterTypes);
                    if (invokeMethod == null || invokeMethod.DeclaringType == typeof(UltEvent) || invokeMethod.DeclaringType.Name.StartsWith(nameof(UltEvent) + "`"))
                    {
                        parameters = null;
                    }
                    else
                    {
                        parameters = invokeMethod.GetParameters();
                    }

                    EventTypeToParameters.Add(type, parameters);
                }

                return parameters;
            }
        }

        /************************************************************************************************************************/

        private static readonly Dictionary<Type, string>
            EventTypeToParameterString = new Dictionary<Type, string>();

        internal string ParameterString
        {
            get
            {
                var type = GetType();

                if (!EventTypeToParameterString.TryGetValue(type, out var parameters))
                {
                    if (ParameterTypes.Length == 0)
                    {
                        parameters = " ()";
                    }
                    else
                    {
                        var invokeMethodParameters = Parameters;

                        var text = new StringBuilder();

                        text.Append(" (");
                        for (int i = 0; i < ParameterTypes.Length; i++)
                        {
                            if (i > 0)
                                text.Append(", ");

                            text.Append(ParameterTypes[i].GetNameCS(false));

                            if (invokeMethodParameters != null)
                            {
                                text.Append(" ");
                                text.Append(invokeMethodParameters[i].Name);
                            }
                        }
                        text.Append(")");

                        parameters = text.ToString();
                    }

                    EventTypeToParameterString.Add(type, parameters);
                }

                return parameters;
            }
        }

        /************************************************************************************************************************/
#endif
        #endregion
        /************************************************************************************************************************/

        /// <summary>
        /// Clears all <see cref="PersistentCalls"/> and <see cref="DynamicCalls"/> registered to this event.
        /// </summary>
        public void Clear()
        {
            if (_PersistentCalls != null)
                _PersistentCalls.Clear();

            DynamicCalls = null;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Returns true if this event has any <see cref="PersistentCalls"/> or <see cref="DynamicCalls"/> registered.
        /// </summary>
        public bool HasCalls
        {
            get
            {
                return (_PersistentCalls != null && _PersistentCalls.Count > 0) || DynamicCalls != null;
            }
        }

        /************************************************************************************************************************/

        /// <summary>Copies the contents of this the 'target' event to this event.</summary>
        public virtual void CopyFrom(UltEventBase target)
        {
            if (target._PersistentCalls == null)
            {
                _PersistentCalls = null;
            }
            else
            {
                if (_PersistentCalls == null)
                    _PersistentCalls = new List<PersistentCall>();
                else
                    _PersistentCalls.Clear();

                for (int i = 0; i < target._PersistentCalls.Count; i++)
                {
                    var call = new PersistentCall();
                    call.CopyFrom(target._PersistentCalls[i]);
                    _PersistentCalls.Add(call);
                }
            }

            DynamicCalls = target.DynamicCalls;

#if UNITY_EDITOR
            _DynamicCallInvocationList = target._DynamicCallInvocationList;
#endif
        }

        /************************************************************************************************************************/

        /// <summary>Returns a description of this event.</summary>
        public override string ToString()
        {
            var text = new StringBuilder();
            ToString(text);
            return text.ToString();
        }

        /// <summary>Appends a description of this event.</summary>
        public void ToString(StringBuilder text)
        {
            text.Append(GetType().GetNameCS());

            text.Append(": PersistentCalls=");
            UltEventUtils.AppendDeepToString(text, _PersistentCalls.GetEnumerator(), "\n    ");

            text.Append("\n    DynamicCalls=");
#if UNITY_EDITOR
            var invocationList = GetDynamicCallInvocationList();
#else
            var invocationList = DynamicCalls?.GetInvocationList();
#endif
            UltEventUtils.AppendDeepToString(text, invocationList?.GetEnumerator(), "\n    ");
        }

        /************************************************************************************************************************/
    }
}