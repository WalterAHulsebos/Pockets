﻿// UltEvents // Copyright 2018 Kybernetik //

using System;
using UnityEngine;
using UnityEngine.Events;

namespace UltEvents
{
    /// <summary>
    /// A serializable event with 1 parameter which can be viewed and configured in the inspector.
    /// <para></para>
    /// This is a more versatile and user friendly implementation than <see cref="UnityEvent{T0}"/>.
    /// </summary>
    [Serializable]
    public class UltEvent<T0> : UltEventBase
    {
        /************************************************************************************************************************/
        #region Fields and Properties
        /************************************************************************************************************************/

        /// <summary>
        /// Delegates registered to this event are serialized as <see cref="PersistentCall"/>s and are invoked by
        /// <see cref="Invoke"/> before all <see cref="dynamicCalls"/>.
        /// </summary>
        public event Action<T0> persistentCalls
        {
            add
            {
                AddPersistentCall(value);
            }
            remove
            {
                RemovePersistentCall(value);
            }
        }

        /************************************************************************************************************************/

        private Action<T0> _DynamicCalls;

        /// <summary>
        /// Delegates registered here are invoked by <see cref="Invoke"/> after all <see cref="persistentCalls"/>.
        /// </summary>
        public event Action<T0> dynamicCalls
        {
            add
            {
                _DynamicCalls += value;
                OnDynamicCallsChanged();
            }
            remove
            {
                _DynamicCalls -= value;
                OnDynamicCallsChanged();
            }
        }

        /// <summary>
        /// The non-serialized method and parameter details of this event.
        /// Delegates registered here are called by <see cref="Invoke"/> after all <see cref="persistentCalls"/>.
        /// </summary>
        protected override Delegate DynamicCalls { get => _DynamicCalls; set => _DynamicCalls = value as Action<T0>; }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Operators and Call Registration
        /************************************************************************************************************************/

        /// <summary>
        /// Ensures that 'e' isn't null and adds 'method' to its <see cref="persistentCalls"/> (if in edit mode) or
        /// <see cref="dynamicCalls"/> (in play mode and at runtime).
        /// </summary>
        public static UltEvent<T0> operator +(UltEvent<T0> e, Action<T0> method)
        {
            if (e == null)
                e = new UltEvent<T0>();

#if UNITY_EDITOR
            if (!UnityEditor.EditorApplication.isPlaying && method.Target is UnityEngine.Object)
            {
                e.persistentCalls += method;
                return e;
            }
#endif

            e.dynamicCalls += method;
            return e;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// If 'e' isn't null, this method removes 'method' from its <see cref="persistentCalls"/> (if in edit mode) or
        /// <see cref="dynamicCalls"/> (in play mode and at runtime).
        /// </summary>
        public static UltEvent<T0> operator -(UltEvent<T0> e, Action<T0> method)
        {
            if (e == null)
                return null;

#if UNITY_EDITOR
            if (!UnityEditor.EditorApplication.isPlaying && method.Target is UnityEngine.Object)
            {
                e.persistentCalls -= method;
                return e;
            }
#endif

            e.dynamicCalls -= method;
            return e;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Creates a new <see cref="UltEventBase"/> and adds 'method' to its <see cref="persistentCalls"/> (if in edit
        /// mode), or <see cref="dynamicCalls"/> (in play mode and at runtime).
        /// </summary>
        public static implicit operator UltEvent<T0>(Action<T0> method)
        {
            if (method != null)
            {
                var e = new UltEvent<T0>();
                e += method;
                return e;
            }
            else return null;
        }

        /************************************************************************************************************************/

        /// <summary>Ensures that 'e' isn't null and adds 'method' to its <see cref="dynamicCalls"/>.</summary>
        public static void AddDynamicCall(ref UltEvent<T0> e, Action<T0> method)
        {
            if (e == null)
                e = new UltEvent<T0>();

            e.dynamicCalls += method;
        }

        /// <summary>If 'e' isn't null, this method removes 'method' from its <see cref="dynamicCalls"/>.</summary>
        public static void RemoveDynamicCall(ref UltEvent<T0> e, Action<T0> method)
        {
            if (e != null)
                e.dynamicCalls -= method;
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
#if UNITY_EDITOR

        private Type[] _ParameterTypes = new Type[] { typeof(T0), };

        /// <summary>The types of each of this event's parameters.</summary>
        public override Type[] ParameterTypes => _ParameterTypes;

#endif
        /************************************************************************************************************************/

        /// <summary>
        /// Invokes all <see cref="persistentCalls"/> then all <see cref="dynamicCalls"/>.
        /// <para></para>
        /// See also: <seealso cref="InvokeSafe"/> and <seealso cref="UltEventUtils.InvokeX{T0}(UltEvent{T0}, T0)"/>.
        /// </summary>
        public virtual void Invoke(T0 parameter0)
        {
            CacheParameter(parameter0);
            InvokePersistentCalls();
            _DynamicCalls?.Invoke(parameter0);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Invokes all <see cref="persistentCalls"/> then all <see cref="dynamicCalls"/> inside a try/catch block
        /// which logs any exceptions that are thrown.
        /// <para></para>
        /// See also: <seealso cref="Invoke"/> and <seealso cref="UltEventUtils.InvokeX{T0}(UltEvent{T0}, T0)"/>.
        /// </summary>
        public virtual void InvokeSafe(T0 parameter0)
        {
            try
            {
                Invoke(parameter0);
            }
            catch (Exception ex)
            {
                Debug.LogException(ex);
            }
        }

        /************************************************************************************************************************/
    }
}