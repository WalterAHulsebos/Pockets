﻿// UltEvents // Copyright 2018 Kybernetik //

#if UNITY_EDITOR

using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using UnityEditor;
using UnityEditorInternal;
using UnityEngine;
using Object = UnityEngine.Object;

namespace UltEvents
{
    [CustomPropertyDrawer(typeof(PersistentCall), true)]
    internal sealed class PersistentCallDrawer : PropertyDrawer
    {
        /************************************************************************************************************************/

        public const float
            RowHeight = 16,
            Padding = 2,
            GetSetWidth = 30,
            SuggestionButtonWidth = 16;

        public static readonly GUIStyle
            PopupButtonStyle,
            PopupLabelStyle;

        private static readonly GUIContent
            ArgumentLabel = new GUIContent(),
            MethodNameSuggestionLabel = new GUIContent("?", "Suggest a method name");

        public static readonly Color
            ErrorFieldColor = new Color(1, 0.65f, 0.65f);

        /************************************************************************************************************************/

        static PersistentCallDrawer()
        {
            PopupButtonStyle = new GUIStyle(EditorStyles.popup)
            {
                fixedHeight = RowHeight
            };

            PopupLabelStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize = 10,
                alignment = TextAnchor.MiddleLeft,
                padding = new RectOffset(4, 14, 0, 0)
            };
        }

        /************************************************************************************************************************/

        public override float GetPropertyHeight(SerializedProperty callProperty, GUIContent label)
        {
            if (callProperty.hasMultipleDifferentValues)
            {
                if (DrawerState.GetPersistentArgumentsProperty(callProperty).hasMultipleDifferentValues)
                    return EditorGUIUtility.singleLineHeight;

                if (DrawerState.GetMethodNameProperty(callProperty).hasMultipleDifferentValues)
                    return EditorGUIUtility.singleLineHeight;
            }

            if (DrawerState.GetCall(callProperty).GetMethodSafe() == null)
                return EditorGUIUtility.singleLineHeight;

            callProperty = DrawerState.GetPersistentArgumentsProperty(callProperty);

            return (EditorGUIUtility.singleLineHeight + Padding) * (1 + callProperty.arraySize) - Padding;
        }

        /************************************************************************************************************************/

        public override void OnGUI(Rect position, SerializedProperty callProperty, GUIContent label)
        {
            DrawerState.Current.BeginCall(callProperty);

            var propertyPosition = position;

            // If we are in the reorderable list of an event, adjust the property area to cover the list bounds.
            if (DrawerState.Current.CachePreviousCalls)
            {
                propertyPosition.xMin -= 20;
                propertyPosition.yMin -= 4;
                propertyPosition.width += 4;
            }

            EditorGUI.BeginProperty(propertyPosition, null, callProperty);
            {
                const float Space = 2;

                var x = position.x;
                var xMax = position.xMax;

                position.height = RowHeight;

                // Target Field.
                position.xMax = EditorGUIUtility.labelWidth + 12;
                DoTargetField(position, callProperty, DrawerState.Current.TargetProperty, DrawerState.Current.MethodNameProperty, out bool autoOpenMethodMenu);

                EditorGUI.showMixedValue = DrawerState.Current.PersistentArgumentsProperty.hasMultipleDifferentValues || DrawerState.Current.MethodNameProperty.hasMultipleDifferentValues;

                var method = EditorGUI.showMixedValue ? null : DrawerState.Current.call.GetMethodSafe();

                // Method Name Dropdown.
                position.x += position.width + Space;
                position.xMax = xMax;
                DoMethodField(position, method, autoOpenMethodMenu);

                // Persistent Arguments.
                if (method != null)
                {
                    position.x = x;
                    position.xMax = xMax;

                    DrawerState.Current.callParameters = method.GetParameters();
                    if (DrawerState.Current.callParameters.Length == DrawerState.Current.PersistentArgumentsProperty.arraySize)
                    {
                        var labelWidth = EditorGUIUtility.labelWidth;
                        EditorGUIUtility.labelWidth -= position.x - 14;

                        for (int i = 0; i < DrawerState.Current.callParameters.Length; i++)
                        {
                            DrawerState.Current.parameterIndex = i;
                            position.y += position.height + Padding;

                            ArgumentLabel.text = DrawerState.Current.callParameters[i].Name;

                            var argumentProperty = DrawerState.Current.PersistentArgumentsProperty.GetArrayElementAtIndex(i);

                            if (argumentProperty.propertyPath != "")
                            {
                                EditorGUI.PropertyField(position, argumentProperty, ArgumentLabel);
                            }
                            else
                            {
                                if (GUI.Button(position, new GUIContent(
                                           "Reselect these objects to show arguments",
                                           "This is the result of a bug in the way Unity updates the SerializedProperty for an array after it is resized while multiple objects are selected")))
                                {
                                    var selection = Selection.objects;
                                    Selection.objects = new Object[0];
                                    EditorApplication.delayCall += () => Selection.objects = selection;
                                }

                                break;
                            }
                        }

                        EditorGUIUtility.labelWidth = labelWidth;
                    }
                    else
                    {
                        Debug.LogError("Method parameter count doesn't match serialized argument count " + DrawerState.Current.callParameters.Length
                            + " : " + DrawerState.Current.PersistentArgumentsProperty.arraySize);
                    }
                    DrawerState.Current.callParameters = null;
                }

                EditorGUI.showMixedValue = false;
            }
            EditorGUI.EndProperty();

            DrawerState.Current.EndCall();
        }

        /************************************************************************************************************************/
        #region Target Field
        /************************************************************************************************************************/

        private static void DoTargetField(Rect position, SerializedProperty callProperty, SerializedProperty targetProperty, SerializedProperty methodNameProperty, out bool autoOpenMethodMenu)
        {
            autoOpenMethodMenu = false;

            // Type field for a static type.
            if (targetProperty.objectReferenceValue == null && !targetProperty.hasMultipleDifferentValues)
            {
                var methodName = methodNameProperty.stringValue;
                string typeName;

                var lastDot = methodName.LastIndexOf('.');
                if (lastDot >= 0)
                {
                    typeName = methodName.Substring(0, lastDot);
                    lastDot++;
                    methodName = methodName.Substring(lastDot, methodName.Length - lastDot);
                }
                else typeName = "";

                var color = GUI.color;
                if (Type.GetType(typeName) == null)
                    GUI.color = ErrorFieldColor;

                const float
                    ObjectPickerButtonWidth = 35,
                    Padding = 2;

                position.width -= ObjectPickerButtonWidth + Padding;

                EditorGUI.BeginChangeCheck();
                typeName = ObjectPicker.DrawTypeField(position, typeName, GetAllTypes, 0, EditorStyles.miniButton);
                if (EditorGUI.EndChangeCheck())
                {
                    methodNameProperty.stringValue = typeName + "." + methodName;
                }

                HandleTargetFieldDragAndDrop(position, callProperty, ref autoOpenMethodMenu);

                GUI.color = color;

                position.x += position.width + Padding;
                position.width = ObjectPickerButtonWidth;
            }

            // Object field for an object reference.
            DoTargetObjectField(position, callProperty, targetProperty, ref autoOpenMethodMenu);
        }

        /************************************************************************************************************************/

        private static void DoTargetObjectField(Rect position, SerializedProperty callProperty, SerializedProperty targetProperty, ref bool autoOpenMethodMenu)
        {
            if (targetProperty.hasMultipleDifferentValues)
                EditorGUI.showMixedValue = true;

            EditorGUI.BeginChangeCheck();

            var oldTarget = targetProperty.objectReferenceValue;
            var target = EditorGUI.ObjectField(position, oldTarget, typeof(Object), true);
            if (EditorGUI.EndChangeCheck())
            {
                SetBestTarget(callProperty, oldTarget, target, out autoOpenMethodMenu);
            }

            EditorGUI.showMixedValue = false;
        }

        /************************************************************************************************************************/

        private static List<Type> _AllTypes;

        private static List<Type> GetAllTypes()
        {
            if (_AllTypes == null)
            {
                // Gather all types in all currently loaded assemblies.
                _AllTypes = new List<Type>(4192);

                var assemblies = AppDomain.CurrentDomain.GetAssemblies();
                for (int i = 0; i < assemblies.Length; i++)
                {
                    var types = assemblies[i].GetTypes();
                    for (int j = 0; j < types.Length; j++)
                    {
                        var type = types[j];
                        if (!type.ContainsGenericParameters &&// No Generics (because the type picker field doesn't let you pick generic parameters).
                            !type.IsInterface &&// No Interfaces (because they can't have any static methods).
                            !type.IsDefined(typeof(ObsoleteAttribute), true) &&// No Obsoletes.
                            type.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static).Length > 0)// No types without any static methods.
                        {
                            // The type might still not have any valid methods, but at least we've narrowed down the list a lot.

                            _AllTypes.Add(type);
                        }
                    }
                }

                _AllTypes.Sort((a, b) => a.FullName.CompareTo(b.FullName));

                // We probably just allocated thousands of arrays with all those GetMethods calls, so call for a cleanup imediately.
                GC.Collect();
            }

            return _AllTypes;
        }

        /************************************************************************************************************************/

        private static void HandleTargetFieldDragAndDrop(Rect position, SerializedProperty callProperty, ref bool autoOpenMethodMenu)
        {
            // Drag and drop objects into the type field.
            switch (Event.current.type)
            {
                case EventType.Repaint:
                case EventType.DragUpdated:
                    {
                        if (!position.Contains(Event.current.mousePosition))
                            break;

                        var dragging = DragAndDrop.objectReferences;
                        if (dragging != null && dragging.Length == 1)
                        {
                            DragAndDrop.visualMode = DragAndDropVisualMode.Copy;
                        }
                    }
                    break;

                case EventType.DragPerform:
                    {
                        if (!position.Contains(Event.current.mousePosition))
                            break;

                        var dragging = DragAndDrop.objectReferences;
                        if (dragging != null && dragging.Length == 1)
                        {
                            SetBestTarget(callProperty, DrawerState.Current.TargetProperty.objectReferenceValue, dragging[0], out autoOpenMethodMenu);

                            DragAndDrop.AcceptDrag();
                            GUI.changed = true;
                        }
                    }
                    break;

                default:
                    break;
            }
        }

        /************************************************************************************************************************/

        private static void SetBestTarget(SerializedProperty callProperty, Object oldTarget, Object newTarget, out bool autoOpenMethodMenu)
        {
            // It's more likely that the user intends to target a method on a Component than the GameObject itself so
            // if a GameObject was dropped in, try to select a component with the same type as the old target,
            // otherwise select it's first component after the Transform.
            if (!(oldTarget is GameObject) && newTarget is GameObject gameObject)
            {
                if (oldTarget is Component oldComponent)
                {
                    newTarget = gameObject.GetComponent(oldComponent.GetType());
                    if (newTarget != null)
                        goto FoundTarget;
                }

                var components = gameObject.GetComponents<Component>();
                newTarget = components.Length > 1 ? components[1] : components[0];
            }

            FoundTarget:

            SetTarget(newTarget);

            autoOpenMethodMenu = MethodSelectionMenu.AutoOpenMenu && newTarget != null && DrawerState.Current.call.GetMethodSafe() == null;
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/

        private static void DoMethodField(Rect position, MethodInfo method, bool autoOpenMethodMenu)
        {
            EditorGUI.BeginProperty(position, null, DrawerState.Current.MethodNameProperty);
            {
                if (includeRemoveButton)
                    position.width -= RemoveButtonWidth;

                var color = GUI.color;

                string label;
                if (EditorGUI.showMixedValue)
                {
                    label = "Mixed Values";
                }
                else if (method != null)
                {
                    label = MethodSelectionMenu.GetMethodSignature(method, false);

                    DoGetSetToggle(ref position, DrawerState.Current.CallProperty, method);
                }
                else
                {
                    var methodName = DrawerState.Current.MethodNameProperty.stringValue;
                    PersistentCall.GetMethodDetails(methodName, DrawerState.Current.TargetProperty.objectReferenceValue, out Type declaringType, out label);
                    DoMethodNameSuggestion(ref position, DrawerState.Current.CallProperty, declaringType, methodName);
                    GUI.color = ErrorFieldColor;
                }

                if (autoOpenMethodMenu || (GUI.Button(position, GUIContent.none, PopupButtonStyle) && Event.current.button == 0))
                {
                    MethodSelectionMenu.ShowMenu(position);
                }

                GUI.color = color;

                PopupLabelStyle.fontStyle = DrawerState.Current.MethodNameProperty.prefabOverride ? FontStyle.Bold : FontStyle.Normal;
                GUI.Label(position, label, PopupLabelStyle);
            }
            EditorGUI.EndProperty();
        }

        /************************************************************************************************************************/

        private static void DoGetSetToggle(ref Rect position, SerializedProperty callProperty, MethodInfo method)
        {
            // Check if the method name starts with "get_" or "set_".
            // Check the underscore first since it's hopefully the rarest so it can break out early.

            var name = method.Name;
            if (name.Length <= 4 || name[3] != '_' || name[2] != 't' || name[1] != 'e')
                return;

            var first = name[0];
            var isGet = first == 'g';
            var isSet = first == 's';
            if (isGet || isSet)
            {
                const BindingFlags Bindings = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;

                var oppositePropertyMethod = method.DeclaringType.GetMethod((isGet ? "set_" : "get_") + name.Substring(4, name.Length - 4), Bindings);
                if (oppositePropertyMethod != null)
                {
                    if (isGet && !MethodSelectionMenu.IsSupported(method.ReturnType))
                        return;

                    position.width -= GetSetWidth + Padding;

                    var buttonPosition = new Rect(
                        position.x + position.width + Padding,
                        position.y,
                        GetSetWidth,
                        position.height);

                    if (GUI.Button(buttonPosition, isGet ? "Set" : "Get"))
                    {
                        var cachedState = new DrawerState();
                        cachedState.CopyFrom(DrawerState.Current);

                        EditorApplication.delayCall += () =>
                        {
                            DrawerState.Current.CopyFrom(cachedState);

                            SetMethod(oppositePropertyMethod);

                            DrawerState.Current.Clear();

                            InternalEditorUtility.RepaintAllViews();
                        };
                    }
                }
            }
        }

        /************************************************************************************************************************/

        private static void DoMethodNameSuggestion(ref Rect position, SerializedProperty callProperty, Type declaringType, string methodName)
        {
            if (declaringType == null ||
                string.IsNullOrEmpty(methodName))
                return;

            var lastDot = methodName.LastIndexOf('.');
            if (lastDot >= 0)
            {
                lastDot++;
                if (lastDot >= methodName.Length)
                    return;

                methodName = methodName.Substring(lastDot);
            }

            var methods = declaringType.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static);
            if (methods.Length == 0)
                return;

            position.width -= SuggestionButtonWidth + Padding;

            var buttonPosition = new Rect(
                position.x + position.width + Padding,
                position.y,
                SuggestionButtonWidth,
                position.height);

            if (GUI.Button(buttonPosition, MethodNameSuggestionLabel))
            {
                var cachedState = new DrawerState();
                cachedState.CopyFrom(DrawerState.Current);

                EditorApplication.delayCall += () =>
                {
                    DrawerState.Current.CopyFrom(cachedState);

                    var bestMethod = methods[0];
                    var bestDistance = UltEventUtils.CalculateLevenshteinDistance(methodName, bestMethod.Name);

                    var i = 1;
                    for (; i < methods.Length; i++)
                    {
                        var method = methods[i];
                        var distance = UltEventUtils.CalculateLevenshteinDistance(methodName, method.Name);

                        if (bestDistance > distance)
                        {
                            bestDistance = distance;
                            bestMethod = method;
                        }
                    }

                    SetMethod(bestMethod);

                    DrawerState.Current.Clear();

                    InternalEditorUtility.RepaintAllViews();
                };
            }
        }

        /************************************************************************************************************************/

        public static void SetTarget(Object target)
        {
            DrawerState.Current.TargetProperty.objectReferenceValue = target;
            DrawerState.Current.TargetProperty.serializedObject.ApplyModifiedProperties();

            if (target == null ||
                DrawerState.Current.call.GetMethodSafe() == null)
            {
                SetMethod(null);
            }
        }

        /************************************************************************************************************************/

        public static void SetMethod(MethodInfo methodInfo)
        {
            SerializedPropertyAccessor.ModifyValues<PersistentCall>(DrawerState.Current.CallProperty,
                (call) => call?.SetMethod(methodInfo, DrawerState.Current.TargetProperty.objectReferenceValue), "Set Method");
        }

        /************************************************************************************************************************/
        #region Remove Button
        /************************************************************************************************************************/

        public const float RemoveButtonWidth = 18;

        public static bool includeRemoveButton;

        /************************************************************************************************************************/

        public static bool DoRemoveButton(Rect rowRect)
        {
            includeRemoveButton = false;

            rowRect.xMin = rowRect.xMax - RemoveButtonWidth + 2;
            rowRect.height = EditorGUIUtility.singleLineHeight + 2;

            return GUI.Button(rowRect, ReorderableList.defaultBehaviours.iconToolbarMinus, ReorderableList.defaultBehaviours.preButton);
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
    }
}

#endif