﻿// UltEvents // Copyright 2018 Kybernetik //

#if UNITY_EDITOR

using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
using UnityEngine;

namespace UltEvents
{
    internal sealed class DrawerState
    {
        /************************************************************************************************************************/

        public static readonly DrawerState Current = new DrawerState();

        /************************************************************************************************************************/

        /// <summary>The <see cref="SerializedProperty"/> for the event currently being drawn.</summary>
        public SerializedProperty EventProperty { get; private set; }

        /// <summary>The event currently being drawn.</summary>
        public UltEventBase Event { get; private set; }

        /************************************************************************************************************************/

        /// <summary>The <see cref="SerializedProperty"/> for the call currently being drawn.</summary>
        public SerializedProperty CallProperty { get; private set; }

        /// <summary>The <see cref="SerializedProperty"/> for the target of the call currently being drawn.</summary>
        public SerializedProperty TargetProperty { get; private set; }

        /// <summary>The <see cref="SerializedProperty"/> for the method name of the call currently being drawn.</summary>
        public SerializedProperty MethodNameProperty { get; private set; }

        /// <summary>The <see cref="SerializedProperty"/> for the persistent arguments array of the call currently being drawn.</summary>
        public SerializedProperty PersistentArgumentsProperty { get; private set; }

        /// <summary>The index of the call currently being drawn.</summary>
        public int callIndex = -1;

        /// <summary>The call currently being drawn.</summary>
        public PersistentCall call;

        /// <summary>The parameters of the call currently being drawn.</summary>
        public ParameterInfo[] callParameters;

        /// <summary>The index of the parameter currently being drawn.</summary>
        public int parameterIndex;

        /************************************************************************************************************************/

        public bool CachePreviousCalls { get; private set; }

        /// <summary>The calls of the current event that come before the current call currently being drawn.</summary>
        private readonly List<PersistentCall> PreviousCalls = new List<PersistentCall>();

        /// <summary>The methods targeted by the calls of the event currently being drawn.</summary>
        private readonly List<MethodInfo> PersistentMethodCache = new List<MethodInfo>();

        /************************************************************************************************************************/

        public ParameterInfo CurrentParameter
        {
            get { return callParameters[parameterIndex]; }
        }

        /************************************************************************************************************************/

        public void BeginEvent(SerializedProperty eventProperty)
        {
            EventProperty = eventProperty;
            Event = SerializedPropertyAccessor.GetValue<UltEventBase>(eventProperty);
        }

        public void EndEvent()
        {
            EventProperty = null;
            Event = null;
        }

        /************************************************************************************************************************/

        public void BeginCache()
        {
            CacheLinkedArguments();
            CachePreviousCalls = true;
        }

        public void EndCache()
        {
            CachePreviousCalls = false;
            PreviousCalls.Clear();
        }

        /************************************************************************************************************************/

        public void BeginCall(SerializedProperty callProperty)
        {
            CallProperty = callProperty;

            TargetProperty = GetTargetProperty(callProperty);
            MethodNameProperty = GetMethodNameProperty(callProperty);
            PersistentArgumentsProperty = GetPersistentArgumentsProperty(callProperty);

            call = GetCall(callProperty);
        }

        public void EndCall()
        {
            if (CachePreviousCalls)
                PreviousCalls.Add(call);

            call = null;
        }

        /************************************************************************************************************************/

        public static SerializedProperty GetTargetProperty(SerializedProperty callProperty)
        {
            return callProperty.FindPropertyRelative(nameof(PersistentCall._Target));
        }

        public static SerializedProperty GetMethodNameProperty(SerializedProperty callProperty)
        {
            return callProperty.FindPropertyRelative(nameof(PersistentCall._MethodName));
        }

        public static SerializedProperty GetPersistentArgumentsProperty(SerializedProperty callProperty)
        {
            return callProperty.FindPropertyRelative(nameof(PersistentCall._PersistentArguments));
        }

        public static PersistentCall GetCall(SerializedProperty callProperty)
        {
            return SerializedPropertyAccessor.GetValue<PersistentCall>(callProperty);
        }

        /************************************************************************************************************************/
        #region Linked Argument Cache
        /************************************************************************************************************************/

        public void CacheLinkedArguments()
        {
            PersistentMethodCache.Clear();

            if (Event == null || Event._PersistentCalls == null)
                return;

            for (int i = 0; i < Event._PersistentCalls.Count; i++)
            {
                PersistentMethodCache.Add(Event._PersistentCalls[i]?.GetMethodSafe());
            }
        }

        /************************************************************************************************************************/

        public void UpdateLinkedArguments()
        {
            if (Event == null ||
                PersistentMethodCache.Count == 0)
                return;

            for (int i = 0; i < Event._PersistentCalls.Count; i++)
            {
                var call = Event._PersistentCalls[i];
                if (call == null)
                    continue;

                for (int j = 0; j < call._PersistentArguments.Length; j++)
                {
                    var argument = call._PersistentArguments[j];
                    if (argument == null || argument._Type != PersistentArgumentType.ReturnValue)
                        continue;

                    var linkedMethod = PersistentMethodCache[argument.ReturnedValueIndex];

                    if (argument.ReturnedValueIndex < Event._PersistentCalls.Count &&
                        linkedMethod == Event._PersistentCalls[argument.ReturnedValueIndex]?.GetMethodSafe())
                        continue;

                    var index = IndexOfMethod(linkedMethod);
                    if (index >= 0)
                        argument.ReturnedValueIndex = index;
                }
            }

            PersistentMethodCache.Clear();
        }

        /************************************************************************************************************************/

        public int IndexOfMethod(MethodInfo method)
        {
            for (int i = 0; i < Event._PersistentCalls.Count; i++)
            {
                if (Event._PersistentCalls[i]?.GetMethodSafe() == method)
                {
                    return i;
                }
            }

            return -1;
        }

        /************************************************************************************************************************/

        public MethodInfo GetLinkedMethod(int index)
        {
            if (index >= 0 && index < PersistentMethodCache.Count)
                return PersistentMethodCache[index];
            else
                return null;
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Previous Call Cache
        /************************************************************************************************************************/

        public bool TryGetLinkable(Type type, out int linkIndex, out PersistentArgumentType linkType)
        {
            if (Event != null)
            {
                // Parameters.
                var parameterTypes = Event.ParameterTypes;
                for (int i = 0; i < parameterTypes.Length; i++)
                {
                    if (type.IsAssignableFrom(parameterTypes[i]))
                    {
                        linkIndex = i;
                        linkType = PersistentArgumentType.Parameter;
                        return true;
                    }
                }

                // Return Values.
                for (int i = 0; i < PreviousCalls.Count; i++)
                {
                    var method = PreviousCalls[i].GetMethodSafe();
                    if (method == null)
                        continue;

                    if (type.IsAssignableFrom(method.ReturnType))
                    {
                        linkIndex = i;
                        linkType = PersistentArgumentType.ReturnValue;
                        return true;
                    }
                }
            }

            linkIndex = -1;
            linkType = PersistentArgumentType.None;
            return false;
        }

        /************************************************************************************************************************/

        public bool TryGetLinkable(out int linkIndex, out PersistentArgumentType linkType)
        {
            if (callParameters != null)
            {
                return TryGetLinkable(CurrentParameter.ParameterType, out linkIndex, out linkType);
            }
            else
            {
                linkIndex = -1;
                linkType = PersistentArgumentType.None;
                return false;
            }
        }

        /************************************************************************************************************************/

        public int PreviousCallCount
        {
            get { return PreviousCalls.Count; }
        }

        /************************************************************************************************************************/

        public PersistentCall GetPreviousCall(int index)
        {
            if (index >= 0 && index < PreviousCalls.Count)
                return PreviousCalls[index];
            else
                return null;
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/

        public void CopyFrom(DrawerState other)
        {
            EventProperty = other.EventProperty;
            Event = other.Event;

            CallProperty = other.CallProperty;
            TargetProperty = other.TargetProperty;
            MethodNameProperty = other.MethodNameProperty;
            PersistentArgumentsProperty = other.PersistentArgumentsProperty;

            callIndex = other.callIndex;
            call = other.call;
            callParameters = other.callParameters;
            parameterIndex = other.parameterIndex;

            PreviousCalls.Clear();
            PreviousCalls.AddRange(other.PreviousCalls);
        }

        /************************************************************************************************************************/

        public void Clear()
        {
            EventProperty = null;
            Event = null;

            CallProperty = null;
            TargetProperty = null;
            MethodNameProperty = null;
            PersistentArgumentsProperty = null;

            callIndex = -1;
            call = null;
            callParameters = null;
            parameterIndex = 0;

            PreviousCalls.Clear();
        }

        /************************************************************************************************************************/
    }
}

#endif