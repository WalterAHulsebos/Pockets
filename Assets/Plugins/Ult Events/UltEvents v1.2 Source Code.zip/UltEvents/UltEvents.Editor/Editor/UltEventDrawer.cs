﻿// UltEvents // Copyright 2018 Kybernetik //

#if UNITY_EDITOR

using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
using UnityEditorInternal;
using UnityEngine;

namespace UltEvents
{
    [CustomPropertyDrawer(typeof(UltEventBase), true)]
    internal sealed class UltEventDrawer : PropertyDrawer
    {
        /************************************************************************************************************************/

        public const float
            Border = 1,
            Padding = 5,
            BaseFooterHeight = 13,
            IndentSize = 15;

        private static readonly GUIContent
            EventLabel = new GUIContent(),
            CountLabel = new GUIContent(),
            PlusLabel = EditorGUIUtility.IconContent("Toolbar Plus", "Add to list");

        private static readonly GUIStyle
            HeaderBackground = new GUIStyle("RL Header"),
            PlusButton = "RL FooterButton";

        private static ReorderableList _CurrentCallList;
        private static int _CurrentCallCount;

        /************************************************************************************************************************/

        static UltEventDrawer()
        {
            HeaderBackground.fixedHeight -= 1;
        }

        /************************************************************************************************************************/

        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            if (!property.isExpanded)
            {
                return EditorGUIUtility.singleLineHeight;
            }
            else
            {
                CachePersistentCallList(property);

                _CurrentCallList.footerHeight = BaseFooterHeight;
                if (property.isExpanded && property.serializedObject.targetObjects.Length == 1)
                {
                    DrawerState.Current.BeginEvent(property);
                    if (DrawerState.Current.Event.HasAnyDynamicCalls())
                        _CurrentCallList.footerHeight += DrawerState.Current.Event.GetDynamicCallInvocationListCount() * EditorGUIUtility.singleLineHeight + 1;
                    DrawerState.Current.EndEvent();
                }

                return _CurrentCallList.GetHeight() - 1;
            }
        }

        /************************************************************************************************************************/

        private float CalculateCallHeight(int index)
        {
            if (index >= 0 && index < _CurrentCallCount)
            {
                var height = EditorGUI.GetPropertyHeight(_CurrentCallList.serializedProperty.GetArrayElementAtIndex(index));
                height += Border * 2 + Padding;

                if (index == _CurrentCallCount - 1)
                    height -= Padding - 1;

                return height;
            }
            else return 0;
        }

        /************************************************************************************************************************/

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            DrawerState.Current.BeginEvent(property);

            EventLabel.text = label.text + DrawerState.Current.Event.ParameterString;
            EventLabel.tooltip = label.tooltip;

            position = EditorGUI.IndentedRect(position);
            position.y -= 1;

            var indentLevel = EditorGUI.indentLevel;
            EditorGUI.indentLevel = 0;

            CachePersistentCallList(property);
            if (property.isExpanded)
            {
                DrawerState.Current.BeginCache();

                _CurrentCallList.DoList(position);

                DrawerState.Current.EndCache();
            }
            else
            {
                if (Event.current.type == EventType.Repaint)
                    HeaderBackground.Draw(position, false, false, false, false);

                DrawHeader(new Rect(position.x + 6, position.y + 1, position.width - 12, position.height));
            }

            position.y += 1;
            position.height = HeaderBackground.fixedHeight;
            property.isExpanded = EditorGUI.Foldout(position, property.isExpanded, "", true);
            CheckDragDrop(position);

            EditorGUI.indentLevel = indentLevel;

            DrawerState.Current.EndEvent();
        }

        /************************************************************************************************************************/

        private readonly Dictionary<string, ReorderableList>
            PropertyPathToList = new Dictionary<string, ReorderableList>();

        private void CachePersistentCallList(SerializedProperty eventProperty)
        {
            var path = eventProperty.propertyPath;
            if (!PropertyPathToList.TryGetValue(path, out _CurrentCallList))
            {
                eventProperty = eventProperty.FindPropertyRelative(nameof(UltEventBase._PersistentCalls));

                _CurrentCallList = new ReorderableList(eventProperty.serializedObject, eventProperty, true, true, true, true)
                {
                    drawHeaderCallback = DrawHeader,
                    drawElementCallback = DrawPersistentCall,
                    drawFooterCallback = DrawFooter,
                    onAddCallback = AddNewCall,
                    onReorderCallback = OnReorder,
                    elementHeight = 19,// Used when the list is empty.
                    elementHeightCallback = CalculateCallHeight,
                    drawElementBackgroundCallback = DrawElementBackground,
                };

                PropertyPathToList.Add(path, _CurrentCallList);
            }

            _CurrentCallCount = _CurrentCallList.count;
        }

        /************************************************************************************************************************/

        private void DrawHeader(Rect position)
        {
            EditorGUI.BeginProperty(position, GUIContent.none, DrawerState.Current.EventProperty);

            const float
                AddButtonWidth = 16,
                AddButtonPadding = 2;

            var labelStyle = DrawerState.Current.EventProperty.prefabOverride ? EditorStyles.boldLabel : GUI.skin.label;

            CountLabel.text = _CurrentCallCount.ToString();
            var countLabelWidth = EditorStyles.boldLabel.CalcSize(CountLabel).x;

            position.width -= AddButtonWidth + AddButtonPadding + countLabelWidth;
            GUI.Label(position, EventLabel, labelStyle);

            position.x += position.width;
            position.width = countLabelWidth;
            GUI.Label(position, CountLabel, labelStyle);

            position.x += position.width + AddButtonPadding + 1;
            position.width = AddButtonWidth;
            position.y -= 1;

            if (GUI.Button(position, PlusLabel, PlusButton))
            {
                DrawerState.Current.EventProperty.isExpanded = true;
                AddNewCall(_CurrentCallList);
            }

            EditorGUI.EndProperty();
        }

        /************************************************************************************************************************/

        public void DrawElementBackground(Rect rect, int index, bool selected, bool focused)
        {
            if (Event.current.type != EventType.Repaint)
                return;

            rect.y -= 2;
            rect.height = CalculateCallHeight(index) + 2;

            if (index == _CurrentCallCount - 1)
                rect.height += 2;

            ReorderableList.defaultBehaviours.elementBackground.Draw(rect, false, selected, selected, focused);

            if (index >= 0 && index < _CurrentCallCount - 1)
            {
                rect.xMin += 1;
                rect.xMax -= 1;
                rect.y += rect.height - 3;
                rect.height = 1;

                DrawSeparatorLine(rect);
            }
        }

        /************************************************************************************************************************/

        private static GUIStyle _SeparatorLineStyle;
        private static readonly Color SeparatorLineColor =
            EditorGUIUtility.isProSkin ? new Color(0.157f, 0.157f, 0.157f) : new Color(0.5f, 0.5f, 0.5f);

        private static void DrawSeparatorLine(Rect rect)
        {
            if (Event.current.type == EventType.Repaint)
            {
                if (_SeparatorLineStyle == null)
                {
                    _SeparatorLineStyle = new GUIStyle();
                    _SeparatorLineStyle.normal.background = EditorGUIUtility.whiteTexture;
                    _SeparatorLineStyle.stretchWidth = true;
                }

                var oldColor = GUI.color;
                GUI.color = SeparatorLineColor;
                _SeparatorLineStyle.Draw(rect, false, false, false, false);
                GUI.color = oldColor;
            }
        }

        /************************************************************************************************************************/

        private void DrawPersistentCall(Rect rect, int index, bool isActive, bool isFocused)
        {
            DrawerState.Current.callIndex = index;
            var callProperty = _CurrentCallList.serializedProperty.GetArrayElementAtIndex(index);

            rect.x += Border;
            rect.y += Border;
            rect.height -= Border * 2;

            PersistentCallDrawer.includeRemoveButton = true;

            EditorGUI.PropertyField(rect, callProperty);

            if (PersistentCallDrawer.DoRemoveButton(rect))
                DelayedRemoveCall(index);

            DrawerState.Current.callIndex = -1;
        }

        /************************************************************************************************************************/

        private static GUIStyle _FooterBackground;

        public void DrawFooter(Rect rect)
        {
            const float
                InvokePadding = 2,
                AddRemoveWidth = 16,
                RightSideOffset = 5;

            var width = rect.width;
            rect.xMin -= 1;

            // Background.
            if (Event.current.type == EventType.Repaint)
            {
                if (_FooterBackground == null)
                {
                    _FooterBackground = new GUIStyle(ReorderableList.defaultBehaviours.footerBackground)
                    {
                        fixedHeight = 0
                    };
                }

                _FooterBackground.Draw(rect, false, false, false, false);
            }

            rect.y -= 3;
            rect.width -= InvokePadding + AddRemoveWidth * 2 + RightSideOffset;
            rect.height = EditorGUIUtility.singleLineHeight;

            if (DrawerState.Current.EventProperty.serializedObject.targetObjects.Length > 1)
            {
                // Multiple Objects Selected.
                rect.xMin += 2;
                GUI.Label(rect, "Can't show Dynamic Listeners for multiple objects");
            }
            else if (DrawerState.Current.Event != null)
            {
                rect.xMin += 16;
                var labelWidth = rect.width;
                rect.xMax = EditorGUIUtility.labelWidth + IndentSize;

                GUI.Label(rect, "Dynamic Listeners");

                // Dynamic Listener Foldout.

                var dynamicListenerCount = DrawerState.Current.Event.GetDynamicCallInvocationListCount();
                if (dynamicListenerCount > 0)
                {
                    var isExpanded = EditorGUI.Foldout(rect, _CurrentCallList.serializedProperty.isExpanded, GUIContent.none, true);
                    _CurrentCallList.serializedProperty.isExpanded = isExpanded;
                    if (isExpanded && DrawerState.Current.Event.HasAnyDynamicCalls())
                    {
                        DrawDynamicListeners(rect.x, rect.y + EditorGUIUtility.singleLineHeight - 1, width, DrawerState.Current.Event);
                    }
                }

                // Dynamic Listener Count.
                rect.x += rect.width;
                rect.width = labelWidth - rect.width;
                GUI.Label(rect, dynamicListenerCount.ToString());
            }

            // Add.
            rect.x += rect.width + InvokePadding;
            rect.y -= 1;
            rect.width = AddRemoveWidth;
            rect.height = BaseFooterHeight;
            if (GUI.Button(rect, ReorderableList.defaultBehaviours.iconToolbarPlus, ReorderableList.defaultBehaviours.preButton))
            {
                AddNewCall(_CurrentCallList);
            }

            // Remove.
            rect.x += rect.width;
            using (new EditorGUI.DisabledScope(_CurrentCallList.index < 0 || _CurrentCallList.index >= _CurrentCallCount))
            {
                if (GUI.Button(rect, ReorderableList.defaultBehaviours.iconToolbarMinus, ReorderableList.defaultBehaviours.preButton))
                {
                    DelayedRemoveCall(_CurrentCallList.index);
                }
            }
        }

        /************************************************************************************************************************/

        private void DrawDynamicListeners(float x, float y, float width, UltEventBase targetEvent)
        {
            x += IndentSize;
            width -= IndentSize * 2;

            var position = new Rect(x, y, width, EditorGUIUtility.singleLineHeight);

            var calls = targetEvent.GetDynamicCallInvocationList();
            for (int i = 0; i < calls.Length; i++)
            {
                var call = calls[i];
                DrawDelegate(position, call);
                position.y += position.height;
            }
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only]
        /// Draw the target and name of the specified <see cref="Delegate"/>.
        /// </summary>
        public static void DrawDelegate(Rect position, Delegate del)
        {
            var width = position.width;

            position.xMax = EditorGUIUtility.labelWidth + 15;
            if (del.Target is UnityEngine.Object obj)
            {
                // If the target is a Unity Object, draw it in an Object Field so the user can click to ping the object.

                using (new EditorGUI.DisabledScope(true))
                {
                    EditorGUI.ObjectField(position, obj, typeof(UnityEngine.Object), true);
                }
            }
            else if (del.Method.DeclaringType.IsDefined(typeof(System.Runtime.CompilerServices.CompilerGeneratedAttribute), true))
            {
                // Anonymous Methods draw only their method name.

                position.width = width;

                GUI.Label(position, del.Method.GetNameCS());

                return;
            }
            else if (del.Target == null)
            {
                GUI.Label(position, del.Method.DeclaringType.GetNameCS());
            }
            else
            {
                GUI.Label(position, del.Target.ToString());
            }

            position.x += position.width;
            position.width = width - position.width;

            GUI.Label(position, del.Method.GetNameCS(false));
        }

        /************************************************************************************************************************/

        private void AddNewCall(ReorderableList list)
        {
            AddNewCall(list, list.serializedProperty.serializedObject.targetObject);
        }

        private void AddNewCall(ReorderableList list, UnityEngine.Object target)
        {
            list.serializedProperty.InsertArrayElementAtIndex(_CurrentCallCount);
            list.serializedProperty.serializedObject.ApplyModifiedProperties();

            var callProperty = list.serializedProperty.GetArrayElementAtIndex(_CurrentCallCount);
            DrawerState.Current.BeginCall(callProperty);
            PersistentCallDrawer.SetTarget(target);
            DrawerState.Current.EndCall();
        }

        /************************************************************************************************************************/

        private void DelayedRemoveCall(int index)
        {
            var list = _CurrentCallList;
            var property = _CurrentCallList.serializedProperty;
            var state = new DrawerState();
            state.CopyFrom(DrawerState.Current);

            EditorApplication.delayCall += () =>
            {
                DrawerState.Current.CopyFrom(state);

                property.DeleteArrayElementAtIndex(index);

                if (list.index >= property.arraySize - 1)
                    list.index = property.arraySize - 1;

                property.serializedObject.ApplyModifiedProperties();

                DrawerState.Current.UpdateLinkedArguments();
                DrawerState.Current.Clear();

                InternalEditorUtility.RepaintAllViews();
            };
        }

        /************************************************************************************************************************/

        private void OnReorder(ReorderableList list)
        {
            DrawerState.Current.UpdateLinkedArguments();
        }

        /************************************************************************************************************************/

        private void CheckDragDrop(Rect rect)
        {
            if (!rect.Contains(Event.current.mousePosition) ||
                DragAndDrop.objectReferences.Length == 0)
                return;

            switch (Event.current.type)
            {
                case EventType.Repaint:
                case EventType.DragUpdated:
                    DragAndDrop.visualMode = DragAndDropVisualMode.Copy;
                    break;

                case EventType.DragPerform:
                    foreach (var drop in DragAndDrop.objectReferences)
                    {
                        AddNewCall(_CurrentCallList, drop);
                    }
                    DrawerState.Current.EventProperty.isExpanded = true;
                    DragAndDrop.AcceptDrag();
                    GUI.changed = true;
                    break;

                default:
                    break;
            }
        }

        /************************************************************************************************************************/
    }
}

#endif